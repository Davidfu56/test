#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019-04-22 16:52
# @Author  : Weiss
# @File    : generate_report.py
# @Software: PyCharm

class GenerateReport:

    def get_report(self):
        """
        构造生成报告数据信息
        :return:
        """


    def write_to_report(self):
        """
        将报告内容写入文件，目前暂定html
        :return:
        """