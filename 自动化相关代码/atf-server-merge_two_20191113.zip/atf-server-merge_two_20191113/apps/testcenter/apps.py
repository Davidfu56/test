from django.apps import AppConfig


class TestcenterConfig(AppConfig):
    name = 'testcenter'
