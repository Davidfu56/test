# 导入RSA和AES包，加密依赖包，日志包
import base64
import json
import random
import re
import time
from httprunner import logger
from Crypto.Random import get_random_bytes
from frame.frameutils.RSACipher import RSACipher
from frame.frameutils.AESCipher import AESCipher



def setup_hook_encrypt(request, privatekey, publicKey):
    """
    报文加密，并替换原有报文data
    :param request:
    :return:
    """
    encrypt_data = {}
    request_data = json.dumps(request["data"])
    print(request_data)
    # 获取randomkey
    randomKey = get_randomKey()
    print(randomKey.decode(encoding='UTF-8',errors='strict'))
    # 使用前面报文获取的公钥加密randomkey
    encrypt_data['randomKey'] = RSACipher.encrypt(publicKey, randomKey)
    # 业务数据AES加密
    encrypt_data['data'] = AESCipher.encrypt(randomKey, request_data['data'])
    # 排序并加密获取sign值
    # encrypt_data['sign'] = getSign(encrypt_data, privatekey)


def teardown_hooks_decrypt(response):
    pass

def get_randomKey():
    return get_random_bytes(16)



def get_param(key):
    return param[key]



def time_generate1():
    tm = time.strftime('%Y%m%d', time.localtime(time.time()))
    return tm

def time_generate2():
    tm = time.strftime('%Y%m%d%s', time.localtime(time.time()))
    return tm



# 生成订单号
def get_orderId():
    tm = time_generate2()
    seeds = 'abcdefghijklmnopqrstuvwxyz0123456789'
    return tm + ''.join(random.choice(seeds) for i in range(7))


def get_requestKey(response):
    print('pass')
    # url = response.url
    # requestKey = re.search('requestKey=(.*)', url).group(1)
    # print(response.text)
    # response.content = requestKey
    # print(response.content)


################################################################################################
"""
    这是一个分割线
    分割线下边是基础方法内容，一般情况请勿修改
    添加自己的方法，请在分割线上自行添加
    import导入的包请勿修改删除
"""
# 定义参数存储字典
param = {}

# 添加处理参数到parm字典
def add_param(key, value):
    if key in param:
        err_msg = u"The key is already in param: {}".format(key)
        logger.log_error(err_msg)
    param[key] = value

# 生成当前时间
def time_generate(format):
    tm = time.strftime(format, time.localtime(time.time()))
    return tm


# 生成手机号
def phone_generate():
    prelist = ['130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '147', '150', '151', '152', '153',
               '155', '156', '157', '158', '159', '186', '187', '188']
    return random.choice(prelist) + ''.join(random.choice('0123456789') for i in range(8))


# 生成中文名字
def chinese_name(num):
    xing_names = ['赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', '卫', '蒋', '沈', '韩', '杨', '朱', '秦', '尤', '许',
                  '何', '吕', '施', '张', '孔', '曹', '严', '华', '金', '魏', '陶', '姜', '戚', '谢', '邹', '喻', '柏', '水', '窦', '章',
                  '云', '苏', '潘', '葛', '奚', '范', '彭', '郎', '鲁', '韦', '昌', '马', '苗', '凤', '花', '方', '俞', '任', '袁', '柳',
                  '酆', '鲍', '史', '唐', '费', '廉', '岑', '薛', '雷', '贺', '倪', '汤', '滕', '殷', '罗', '毕', '郝', '邬', '安', '常',
                  '乐', '于', '时', '傅', '皮', '卞', '齐', '康', '伍', '余', '元', '卜', '顾', '孟', '平', '黄', '和', '穆', '萧', '尹',
                  '姚', '邵', '堪', '汪', '祁', '毛', '禹', '狄', '米', '贝', '明', '臧', '计', '伏', '成', '戴', '谈', '宋', '茅', '庞',
                  '熊', '纪', '舒', '屈', '项', '祝', '董', '梁']

    ming_names = ['的', '一', '是', '了', '我', '不', '人', '在', '他', '有', '这', '个', '上', '们', '来', '到', '时', '大', '地', '为',
                  '子', '中', '你', '说', '生', '国', '年', '着', '就', '那', '和', '要', '她', '出', '也', '得', '里', '后', '自', '以',
                  '会', '家', '可', '下', '而', '过', '天', '去', '能', '对', '小', '多', '然', '于', '心', '学', '么', '之', '都', '好',
                  '看', '起', '发', '当', '没', '成', '只', '如', '事', '把', '还', '用', '第', '样', '道', '想', '作', '种', '开', '美',
                  '总', '从', '无', '情', '己', '面', '最', '女', '但', '现', '前', '些', '所', '同', '日', '手', '又', '行', '意', '动',
                  '方', '期', '它', '头', '经', '长', '儿', '回', '位', '分', '爱', '老', '因', '很', '给', '名', '法', '间', '斯', '知',
                  '世', '什', '两', '次', '使', '身', '者', '被', '高', '已', '亲', '其', '进', '此', '话', '常', '与', '活', '正', '感',
                  '见', '明', '问', '力', '理', '尔', '点', '文', '几', '定', '本', '公', '特', '做', '外', '孩', '相', '西', '果', '走',
                  '将', '月', '十', '实', '向', '声', '车', '全', '信', '重', '三', '机', '工', '物', '气', '每', '并', '别', '真', '打',
                  '太', '新', '比', '才', '便', '夫', '再', '书', '部', '水', '像', '眼', '等', '体', '却', '加', '电', '主', '界', '门',
                  '利', '海', '受', '听', '表', '德', '少', '克', '代', '员', '许', '稜', '先', '口', '由', '死', '安', '写', '性', '马',
                  '光', '白', '或', '住', '难', '望', '教', '命', '花', '结', '乐', '色', '更', '拉', '东', '神', '记', '处', '让', '母',
                  '父', '应', '直', '字', '场', '平', '报', '友', '关', '放', '至', '张', '认', '接', '告', '入', '笑', '内', '英', '军',
                  '候', '民', '岁', '往', '何', '度', '山', '觉', '路', '带', '万', '男', '边', '风', '解', '叫', '任', '金', '快', '原']

    # 根据传入参数生成名字
    i = 1
    fn = ''
    while i < num:
        i = i + 1
        strf = random.choice(ming_names)
        fn = fn + strf
    chinesename = random.choice(xing_names) + fn
    return chinesename


# # 生成身份证
# def identity_card(areacode=None):
#     discode_path = '../TestCase/Config/DistrictCode.xls'
#     sheetdata = stream.sheet_by_index(0)
#     discode = {}
#     for r in range(1, sheetdata.nrows):
#         key = sheetdata.cell(r, 0).value
#         value = ''
#         for c in range(1, sheetdata.ncols):
#             cell_data = sheetdata.cell(r, c).value
#             value = value + cell_data
#         discode[key] = value
#     if areacode in discode:
#         iid = areacode  # 地区码
#     else:
#         iid = discode.popitem()[0]  # popitem删除并返回一个key-value格式的元组，地区码
#
#     iid = iid + str(random.randint(1930, 2013))  # 年份项
#     dt = date.today() + timedelta(days=random.randint(1, 366))  # 月份和日期项
#     iid = iid + dt.strftime('%m%d')
#     iid = iid + str(random.randint(100, 300))  # 顺序号
#
#     count = 0
#     weight = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]  # 权重项
#     checkcode = {'0': '1', '1': '0', '2': 'X', '3': '9', '4': '8', '5': '7', '6': '6', '7': '5', '8': '5', '9': '3',
#                  '10': '2'}  # 校验码映射
#     for i in range(0, len(iid)):
#         count = count + int(iid[i]) * weight[i]
#     iid = iid + checkcode[str(count % 11)]  # 算出校验码
#     return iid

# 生成地址


if __name__ == '__main__':
    # print(type(get_randomKey()))
    # print(get_randomKey().decode())
    # print(get_randomKey())
    print(get_orderId())